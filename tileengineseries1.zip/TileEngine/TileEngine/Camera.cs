﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace TileEngine
{
    static class Camera
    {
        static public Vector2 Location = Vector2.Zero;
    }
}
