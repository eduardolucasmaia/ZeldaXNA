using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace WindowsGame1
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Mapa mapa = new Mapa(@"Mapas\TextFile1.txt");
        Texture2D chao, parede, jog;
        Vector2 pos;

        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here
            IsMouseVisible = true;
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            parede = Content.Load<Texture2D>("parede");
            chao = Content.Load<Texture2D>("chao");
            jog = Content.Load<Texture2D>("jogador");
            for (int y = 0; y < mapa.Tamanho_Y(); y++)
            {
                for (int x = 0; x < mapa.Tamanho_X(); x++)
                {
                    if (mapa.array[x, y] == '@') { pos = new Vector2(x * jog.Width, y * jog.Height); }
                }
            }
            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            float vel = 2.5f;
            if (Keyboard.GetState().IsKeyDown(Keys.Left)) { pos.X -= vel; }
            if (Keyboard.GetState().IsKeyDown(Keys.Right)) { pos.X += vel; }
            if (Keyboard.GetState().IsKeyDown(Keys.Up)) { pos.Y -= vel; }
            if (Keyboard.GetState().IsKeyDown(Keys.Down)) { pos.Y += vel; }

            ColisaoParedes();

            // TODO: Add your update logic here

            base.Update(gameTime);
        }

        void ColisaoParedes()
        {
            int posX = (int)(pos.X / jog.Width);
            int posY = (int)(pos.Y / jog.Width);

            float maxX = 0, minX = 0; //, maxY = 0, minY = 0;

            if (mapa.array[posX + 1, posY] == '1') { maxX = (jog.Width * posX) - 1; } else { maxX = (jog.Width * posX) + jog.Width; }

            pos.X = MathHelper.Clamp(pos.X, minX, maxX);
            //pos.Y = MathHelper.Clamp(pos.Y, maxY, minY);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();
            for (int y = 0; y < mapa.Tamanho_Y(); y++)
            {
                for (int x = 0; x < mapa.Tamanho_X(); x++)
                {
                    if (mapa.array[x, y] == '1') { spriteBatch.Draw(parede, new Vector2(x * parede.Width, y * parede.Height), Color.White); }
                    if (mapa.array[x, y] == '0' || mapa.array[x, y] == '@') { spriteBatch.Draw(chao, new Vector2(x * chao.Width, y * chao.Height), Color.White); }
                }
            }
            spriteBatch.Draw(jog, pos, Color.White);
            spriteBatch.End();
                // TODO: Add your drawing code here

                base.Draw(gameTime);
        }
    }
}
